<?php include "includes/header.php"; ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
	  <div class="container-fluid">
	    <div class="row mb-2">
	      <div class="col-sm-6">
	        <h1 class="m-0">Dashboard </h1>
	      </div><!-- /.col -->
	      <div class="col-sm-6">
	        <ol class="breadcrumb float-sm-right">
	          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
	          <li class="breadcrumb-item active">Manage Category</li>
	        </ol>
	      </div><!-- /.col -->
	    </div><!-- /.row -->
	  </div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->

	
	<!-- Main content start -->    
	<section class="content">
	    <div class="container-fluid">
	        <!-- Info boxes -->
	        <div class="row">
	        	<!-- right column start  -->
	          	<div class="col-md-6">

	          		<!-- Add category card start  -->
	          		<div class="card card-primary">
	          			<div class="card-header">
	          				<h3 class="card-title">Add New Category</h3>
	          			</div>
	          			<div class="card-body">
	          				<form action="" method="POST">
	          					<div class="form-group">
	          						<label for="">Category Name</label>
	          						<input type="text" name="name" class="form-control" required="required" autocomplete="off">
	          					</div>
	          					<div class="form-group">
	          						<label for="">Category Description</label>
	          						<textarea class="form-control" name="desc" rows="3"></textarea>
	          					</div>
	          					<div class="form-group">
	          						<label for="">Status[Active / Inactive]</label>
	          						<select name="status" class="form-control">
	          							<option value="1">Active</option>
	          							<option value="0">Inactive</option>
	          						</select>
	          					</div>
	          					<div class="form-group">
	          						<input type="submit" class="btn btn-primary" name="submit" value="Add Category">
	          					</div>
	          				</form>
	          				<!-- Create or Insert Data in to database code  -->
	          				<?php

								if (isset($_POST['submit'])) {
									
									// # code...
									$name 	= $_POST['name'];
									$desc 	= $_POST['desc'];
									$status = $_POST['status'];

									$sql = "INSERT INTO categories (cat_name, cat_desc, cat_status) VALUES ('$name', '$desc', '$status')";

									$add_cat = mysqli_query($db, $sql);

									if ($add_cat) {
										# code...
										header("Location: category.php");
									}
									else{
										die("Query Filed" . mysqli_error($db));
									}
									
									
								}
							?>
	          			</div>
	          		</div>
	          		<!-- Add category card end  -->

	          		<!-- Edit category card start  -->

	          		<?php

	          		if (isset($_GET['edit'])) {
	          			# code...

	          			$the_cat_id = $_GET['edit'];
	          			$sql = "SELECT * FROM categories WHERE cat_id = '$the_cat_id' ";

	          			$selected_cat = mysqli_query($db, $sql);

	          			while ( $row = mysqli_fetch_assoc($selected_cat)) {
	          				# code...

	          				$cat_id 		= $row['cat_id'];
							$cat_name 		= $row['cat_name'];
							$cat_desc 		= $row['cat_desc'];
							$cat_status 	= $row['cat_status'];

							?>

							<!-- edit category status -->
							<div class="card card-primary">
			          			<div class="card-header">
			          				<h3 class="card-title">Edit Category</h3>
			          			</div>
			          			<div class="card-body">
			          				<form action="" method="POST">
			          					<div class="form-group">
			          						<label for="">Category Name</label>
			          						<input type="text" name="name" class="form-control" required="required" autocomplete="off" value="<?php echo $cat_name; ?>">
			          					</div>
			          					<div class="form-group">
			          						<label for="">Category Description</label>
			          						<textarea class="form-control" name="desc" rows="3"><?php echo $cat_desc; ?></textarea>
			          					</div>
			          					<div class="form-group">
			          						<label for="">Status[Active / Inactive]</label>
			          						<select name="status" class="form-control">
			          							<option value="1" <?php if ($cat_status == 1) {echo "selected";}?> >Active</option>
			          							<option value="0" <?php if ($cat_status == 0) {echo "selected";}?>>Inactive</option>
			          						</select>
			          					</div>
			          					<div class="form-group">
			          						<input type="submit" class="btn btn-primary" name="updateCategory" value="Save Change">
			          					</div>
			          				</form>
			          				<!-- Update category code  -->
			          				<?php

										if (isset($_POST['updateCategory'])) {
											
											// # code...
											$name 	= $_POST['name'];
											$desc 	= $_POST['desc'];
											$status = $_POST['status'];

											$sql = "UPDATE categories SET cat_name = '$name', cat_desc = '$desc', cat_status = '$status' WHERE cat_id ='$the_cat_id' ";


											$update_cat = mysqli_query($db, $sql);

											if ($update_cat) {
												# code...
												header("Location: category.php");
											}
											else{
												die("Query Filed" . mysqli_error($db));
											}
											
											
											
										}
									?>
			          			</div>
			          		</div>
							<!-- edit category status end  -->

							<?php
	          			}
	          		}

	          		?>

	          		<!-- Edit category card end  -->
	          	</div>
	          	<!-- right column end  -->

	          	<!-- left column start  -->
	          	<div class="col-md-6">
	          		<div class="card card-success">
	          			<div class="card-header">
	          				<h3 class="card-title">All Category</h3>
	          			</div>
	          			<div class="card-body">
	          				<table class="table">
								<thead class="table-dark">
								    <tr>
								      	<th scope="col">SL.</th>
								      	<th scope="col">Category Name</th>
								      	<th scope="col">Status</th>
								      	<th scope="col">Action</th>
								    </tr>
								</thead>
								<tbody>

									<!-- Read form databese table  -->

									<?php

										$sql = "SELECT * FROM categories";
										$all_cat = mysqli_query($db, $sql);

										$i = 0;
										while ( $row = mysqli_fetch_assoc($all_cat)) {
											# code...
											$cat_id 		= $row['cat_id'];
											$cat_name 		= $row['cat_name'];
											$cat_desc 		= $row['cat_desc'];
											$cat_status 	= $row['cat_status'];

											$i++;
											?>

										<tr>
									      	<th scope="row"><?php echo $i ;?></th>
									      	<td><?php echo $cat_name ;?></td>
									      	<td>	
									      		<?php

									      			if ($cat_status == 1) {
									      				echo '<div class="badge badge-success">Active</div>';
									      			}
									      			else{
									      				echo '<div class="badge badge-danger">Inactive</div>';
									      			}
									      		?>
									      	</td>
									      	<td>
									      		<div class="action-menu">
									      			<ul>
									      				<li>
									      					<a href="category.php?edit=<?php echo $cat_id; ?>">
									      						<i class="fa fa-edit" data-toggle="tooltip" data-placement="bottom" title="Edit Category"></i>
									      					</a>
									      				</li>
									      				<li data-toggle="modal" data-target="#delete<?php echo $cat_id; ?>">
									     
									      					<i class="fa fa-trash" data-toggle="tooltip" data-placement="bottom" title="Delete Category"></i>
									      					
									      				</li>

									      			</ul>

									      			<!-- Confiramtion delete Modal -->
													<div class="modal fade" id="delete<?php echo $cat_id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
													  <div class="modal-dialog">
													    <div class="modal-content">
													      <div class="modal-header">
													        <h5 class="modal-title" id="exampleModalLabel">Are you sure to delete this Category ?</h5>
													        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
													          <span aria-hidden="true">&times;</span>
													        </button>
													      </div>
													      <div class="modal-body">
													      	<div class="modal-button">
													      		<a href="category.php?delete=<?php echo $cat_id; ?>" class="btn btn-danger">Yes</a>
													        	<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
													      	</div>
													      </div>
													 
													    </div>
													  </div>
													</div>
									      		</div>
									      	</td>
									    </tr>

									<?php } ?>
								</tbody>
							</table>
	          			</div>

	          			<!-- Delete function -->

			      		<?php
			      			if (isset($_GET['delete']) ) {
			      				# code...

			      				//echo $_GET['delete'];

			      				$the_id = $_GET['delete'];

			      				$sql = "DELETE FROM categories WHERE cat_id = '$the_id' ";

			      				$del_cat = mysqli_query($db, $sql);

			      				if ( $del_cat ) {
			      					# code...
			      					header("Location: category.php");
			      				}
			      				else{
			      					die("Something is wrong" . mysqli_error($db));
			      				}

			      			}
			      		?>
	          		</div>
	          	</div>
	          	<!-- left column end  -->

	      	</div>
	    </div>
	</section>
	<!-- Main content end -->

</div>



<?php include "includes/footer.php"; ?>