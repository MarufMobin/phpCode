<?php include "includes/header.php"; ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
	  <div class="container-fluid">
	    <div class="row mb-2">
	      <div class="col-sm-6">
	        <h1 class="m-0">Dashboard </h1>
	      </div><!-- /.col -->
	      <div class="col-sm-6">
	        <ol class="breadcrumb float-sm-right">
	          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
	          <li class="breadcrumb-item active">Blog </li>
	        </ol>
	      </div><!-- /.col -->
	    </div><!-- /.row -->
	  </div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->


	<?php 

			
	$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

	if ( $do == "Manage") {
		# code...
		?>

		<!-- Main content start -->    
		<section class="content">
		    <div class="container-fluid">
		        <div class="row">
		          	<div class="col-md-12">
		          		<!-- User Management card start  -->
		          		<div class="card card-primary">
		          			<div class="card-header">
		          				<h3 class="card-title">All Comments</h3>
		          			</div>
		          			<div class="card-body">

		          				<table class="table table-striped table-bordered">
									<thead class="table-dark">
									    <tr>
										    <th scope="col">Sl.</th>
										    <th scope="col">Post Ttile</th>
										    <th scope="col">Name</th>
										    <th scope="col">Email</th>
										    <th scope="col">Comments</th>
										    <th scope="col">Status</th>
										    <th scope="col">Date</th>
										    <th scope="col">Action</th>
									    </tr>
									</thead>
									<tbody>

									<?php

									$sql="SELECT * FROM comments ORDER BY cmt_id DESC";
									$all_comments = mysqli_query($db, $sql);
									$i = 0;
									while ( $row = mysqli_fetch_assoc($all_comments) ) {
											
										$cmt_id 		= $row['cmt_id'];
										$cmt_post_id 	= $row['cmt_post_id'];
										$cmt_name 		= $row['cmt_name'];
										$cmt_email 		= $row['cmt_email'];
										$cmt_message 	= $row['cmt_message'];
										$cmt_status 	= $row['cmt_status'];
										$cmt_date 		= $row['cmt_date'];
										$i++

										?>

										<tr>
										    <th scope="row"><?php echo $i ;?></th>
										    <td>
										    	<?php 
													$sql = "SELECT * FROM post WHERE post_id = '$cmt_post_id' ";

								          			$the_post_title = mysqli_query($db, $sql);

								          			while ( $row = mysqli_fetch_assoc($the_post_title)) {
								          				$post_id 	= $row['post_id'];
														$title 		= $row['title'];

													}
													echo $title ;
										    	?>
										    </td>
										    <td> <?php echo $cmt_name; ?> </td>
										    <td> <?php echo $cmt_email; ?> </td>
										    <td> <?php echo $cmt_message; ?> </td>
										    
										    <td>
										    	<?php 
										    		if ( $cmt_status == 1) { 
										    			?>

										    			<span class="badge badge-success">Approved</span>

										    			<?php
										    			
										    		}
										    		else{
										    			?>

										    			<span class="badge badge-danger">Draft</span>
										    			
										    			<?php
										    		}
										    	?>
										    </td>
										    
										    <td><?php echo $cmt_date ;?></td>
										    
										    <td>
										    	
										    	<div class="action-menu">
										    		<ul>
									      				<li>
									      					<a href="comments.php?do=Edit&id=<?php echo $cmt_id; ?>">
									      						<i class="fa fa-edit" data-toggle="tooltip" data-placement="bottom" title="Update Comment"></i>
									      					</a>
									      				</li>
									      				<li data-toggle="modal" data-target="#delete<?php echo $cmt_id; ?>">
									     
									      					<i class="fa fa-trash" data-toggle="tooltip" data-placement="bottom" title="Delete Comment"></i>
									      					
									      				</li>

									      			</ul>


									      			<!-- Modal -->
													<div class="modal fade" id="delete<?php echo $cmt_id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
													  <div class="modal-dialog">
													    <div class="modal-content">
													      <div class="modal-header">
													        <h5 class="modal-title" id="exampleModalLabel">Are you sure to Delete this Comment?</h5>
													        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
													          <span aria-hidden="true">&times;</span>
													        </button>
													      </div>
													      <div class="modal-body">
													      	<div class="modal-button">
												      		<a href="comments.php?do=Delete&the_del_id=<?php echo $cmt_id; ?>" class="btn btn-danger">Yes</a>
												        	<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
												      	</div>
													      </div>
													      
													    </div>
													  </div>
													</div>
										    	</div>
										    </td>
									    </tr>

										<?php } ?>   
									   
									</tbody>
								</table>

		          			</div>
		          		</div>
		          		<!-- User Management card End  -->

		          	</div>

		          	
		      	</div>
		    </div>
		</section>
		<!-- Main content end -->
		
	<?php }

	else if ( $do == "Edit") {
		
			?>
			<!-- Main content start -->    
			<section class="content">
			    <div class="container-fluid">
			        <div class="row">
			          	<div class="col-md-12">
			          		<div class="card card-primary">
			          			<div class="card-header">
			          				<h3 class="card-title">Update Comments</h3>
			          			</div>
			          			<div class="card-body">

			          				<?php
			          					if ( isset($_GET['id']) ) {

										$the_id = $_GET['id'];

										$sql = "SELECT * FROM comments WHERE cmt_id = '$the_id' ";
										$the_comments = mysqli_query($db, $sql);
										while ( $row = mysqli_fetch_assoc( $the_comments )) {

											$cmt_id 		= $row['cmt_id'];
											$cmt_post_id 	= $row['cmt_post_id'];
											$cmt_name 		= $row['cmt_name'];
											$cmt_email 		= $row['cmt_email'];
											$cmt_message 	= $row['cmt_message'];
											$cmt_status 	= $row['cmt_status'];
											$cmt_date 		= $row['cmt_date'];

											?>
											<form action="comments.php?do=Update" method="POST">
				          				
				          						<div class="form-group">
				          							<select name="cmt_status" class="form-control">
				          								
				          								<option value="1" <?php if( $cmt_status == 1){ echo 'selected';}?>>Approved</option>
				          								<option value="0" <?php if( $cmt_status == 0){ echo 'selected';}?>>Draft</option>
				          							</select>
				          						</div>

				          						<div class="form-group">
				          							<input type="hidden" name="updateComment_id" value="<?php echo $cmt_id; ?>">
					          						<input type="submit" name="updateComment" value="Update Comment" class="btn btn-primary">
				          						</div>
	
				          					</div>

				          				</form>

											<?php
										}

			          				?>

			          			</div>
			          		</div>
			          	</div>
			      	</div>
			    </div>
			</section>
			<!-- Main content end -->


			<?php
			
		}
	}
	else if ( $do == "Update") {
		
		if (isset($_POST['updateComment'])) {

			$the_update_id 	= $_POST['updateComment_id'];
			$cmt_status 	= $_POST['cmt_status'];

			$sql = "UPDATE comments SET cmt_status = '$cmt_status' WHERE cmt_id = '$the_update_id' ";

			$update_comment = mysqli_query( $db, $sql);

			if ( $update_comment ) 
			{
				header("Location: comments.php?do=Manage");
			}
			else{
				die("Query Filed" . mysqli_error($db) );
			}
				
		}


	}
	else if ( $do == "Delete") {
		if (isset($_GET['the_del_id'])) {
			
			$del_id = $_GET['the_del_id'];

			// delete user form database

			$del_sql ="DELETE FROM comments WHERE cmt_id = '$del_id ' "; 

			$delete_comment = mysqli_query($db, $del_sql);

			if ( $delete_comment ) {
				header("Location: comments.php?do=Manage");
			}
			else{
				die("Query Field" . mysqli_error($db));
			}
		}
	}


		

	?>



	<!-- Main content start -->    
	<!-- <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	          	<div class="col-md-12">
	          		<div class="card card-primary">
	          			<div class="card-header">
	          				<h3 class="card-title">Add New Category</h3>
	          			</div>
	          			<div class="card-body">




	          			</div>
	          		</div>
	          	</div>
	      	</div>
	    </div>
	</section> -->
	<!-- Main content end -->






</div>



<?php include "includes/footer.php"; ?>