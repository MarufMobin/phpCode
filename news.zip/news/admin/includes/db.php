<?php
	
	// Database connection code goes here...
	
	$db = mysqli_connect('localhost', 'root', '', 'news230');

	if ($db) {
		# code...
		//echo "Database connected successfully";
	}
	else{
		die("Database Connection Faild" . mysqli_error($db));
	}

?>