<?php include "includes/header.php"; ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
	  <div class="container-fluid">
	    <div class="row mb-2">
	      <div class="col-sm-6">
	        <h1 class="m-0">Dashboard </h1>
	      </div><!-- /.col -->
	      <div class="col-sm-6">
	        <ol class="breadcrumb float-sm-right">
	          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
	          <li class="breadcrumb-item active">User Management</li>
	        </ol>
	      </div><!-- /.col -->
	    </div><!-- /.row -->
	  </div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->
<?php 
    
		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

		if ( $do == "Manage") {
			
			?>


			<section class="content">
			    <div class="container-fluid">
			        <!-- Info boxes -->
			        <div class="row">
			          	<div class="col-md-12">
			          		<!-- User Management card Start -->
			          		<div class="card card-primary">
			          			<div class="card-header">
			          				<h3 class="card-title">All Post</h3>
			          			</div>
			          			<div class="card-body">
			          				<table class="table table-striped table-bordered">
									  <thead class="thead-dark">
									    <tr>
									      <th scope="col">Sl.</th>
									      <th scope="col">Title</th>
									      <th scope="col">Thumbnail</th>
									      <th scope="col">Category</th>
									      <th scope="col">Published By</th>
									      <th scope="col">Date</th>
									      <th scope="col">Action</th>
									    </tr>
									  </thead>
									  <tbody>

									  	<?php
									  		$sql ="SELECT * FROM post";
									  		$all_post = mysqli_query($db, $sql);
									  		$i = 0;

									  		while ( $row = mysqli_fetch_assoc($all_post)) {
									  			
									  			$post_id 		= $row['post_id'];
									  			$title 			= $row['title'];
									  			$description 	= $row['description'];
									  			$thumbnail 		= $row['thumbnail'];
									  			$category_id	= $row['category_id'];
									  			$author_id 		= $row['author_id'];
									  			$postDate 		= $row['postDate'];
									  			$i++;

									  			?>
									  			<tr>
											      <th scope="row"><?php echo $i;?></th>
											      <td><?php echo $title; ?></td>
											      <td>

											      	<?php

											      		if (empty($thumbnail)) {
											      			?>
											      				<img src="dist/img/posts/default.jpg" alt="" class="avater-img">
											      			<?php
											      			
											      		}else{
											      			?>
											      				<img src="dist/img/posts/<?php echo $thumbnail; ?>" alt="" class="avater-img">
											      			<?php
											      		}
											      	?>
											      	
											      </td>
											      
											      <td><?php echo $category_id; ?></td>
											      
											      <td><?php echo $author_id; ?></td>

											      <td><?php echo $postDate; ?></td>
											      
											      <td>

											      	<div class="action-menu">
											      		<ul>
										      				<li>
										      					<a href="blog.php?do=Edit&id=<?php echo $post_id; ?>">
										      						<i class="fa fa-edit" data-toggle="tooltip" data-placement="bottom" title="Update Post"></i>
										      					</a>
										      				</li>
										      				<li data-toggle="modal" data-target="#delete<?php echo $post_id; ?>">
										     
										      					<i class="fa fa-trash" data-toggle="tooltip" data-placement="bottom" title="Delete Post"></i>
										      					
										      				</li>

										      			</ul>
										      			<!-- Modal -->
														<div class="modal fade" id="delete<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
														  <div class="modal-dialog">
														    <div class="modal-content">
														      <div class="modal-header">
														        <h5 class="modal-title" id="exampleModalLabel">Are you sure to Delete this Blog Post?</h5>
														        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
														          <span aria-hidden="true">&times;</span>
														        </button>
														      </div>
														      <div class="modal-body">
														      	<div class="modal-button">
													      		<a href="blog.php?do=Delete&deleteUser=<?php echo $post_id; ?>" class="btn btn-danger">Yes</a>
													        	<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
													      	</div>
														      </div>
														      
														    </div>
														  </div>
														</div>
											      	</div>
											      </td>
											      
											     
											    </tr>

									  			<?php
									  		}

									  	?>

									  </tbody>
									</table>
			          			</div>
			          		</div>

			          		<!-- User Management card end -->
			          	</div>

			          	<!-- Add users button -->
			          	<div class="col-md-12">
			          		<a href="blog.php?do=Add" class="btn btn-primary">Add New Post</a>
			          	</div>
			      	</div>
			    </div>
			</section>




			<?php
			
		}
		else if ( $do == "Add") {
			
			?>


			<section class="content">
			    <div class="container-fluid">
			        <div class="row">
			          	<div class="col-md-12">
							<div class="card card-primary">
			          			<div class="card-header">
			          				<h3 class="card-title">Add New User</h3>
			          			</div>
			          			<div class="card-body">

			          				<form action="blog.php?do=Insert" method="POST" enctype="multipart/form-data">
			          					
			          					<div class="row">
			          						<div class="col-md-4">
			          							<div class="form-group">
			          								<label for="">Title</label>
			          								<input type="text" name="title" required="required" class="form-control">
			          							</div>

			          							<div class="form-group">
			          								<label for="">Category Name</label>
			          								<select name="category_id" class="form-control">
			          									<option value="0">Please Select a category</option>

			          									<?php

				          								$sql = "SELECT * FROM categories WHERE cat_status = 1";
														$all_cat = mysqli_query($db, $sql);

														
														while ( $row = mysqli_fetch_assoc($all_cat)) {
															# code...
															$cat_id 		= $row['cat_id'];
															$cat_name 		= $row['cat_name'];
															?>

															<option value="<?php echo $cat_id ;?>"><?php echo $cat_name ;?></option>

															<?php
														}
												
				          								?>
			          								</select>
			          							</div>

			          							<div class="form-group">
			          								<label for="">Post Thumbnail</label>
			          								<input type="file" name="thumbnail" class="form-control-file">
			          							</div>
			          						</div>

			          						<div class="col-md-8">
			          							<div class="form-group">
			          								<label for="">Descriptions</label>
			          								<textarea name="description" class="form-control" cols="20" rows="6" ></textarea>
			          							</div>
			          							<div class="form-group">
			          								<input type="submit" name="publish" class="btn btn-primary" value="Publish Post">
			          							</div>
			          						</div>
			          					</div>

			          				</form>


			          			</div>

					        </div>
			          	</div>
			      	</div>
			    </div>
			</section>

			<?php


		}
		else if ( $do == "Insert") {
			
			if (isset($_POST['publish'])) {
				
				$title 			= $_POST['title'];
				$description 	= $_POST['description'];
				$category_id 	= $_POST['category_id'];
				$author_id		= $_SESSION['id'];

				$thumbnail 		= $_FILES['thumbnail']['name'];
				$image_temp 	= $_FILES['thumbnail']['tmp_name'];

				

				// image file code or name change and move folder code here

				$random_number = rand(0, 1000000);
				$imageFile = $random_number.$thumbnail;

				move_uploaded_file($image_temp, "dist/img/posts/".$imageFile );

				$sql = "INSERT INTO post (title, description, thumbnail, category_id, author_id, postDate ) VALUES ('$title', '$description', '$imageFile', '$category_id', '$author_id', now() ) ";

				$addPost = mysqli_query($db, $sql);

				if ( $addPost ) {
					
					header("Location: blog.php?do=Manage");
				}
				else{
					die("Query Filed!!" .mysqli_error($db));
				}

				


			}
		}
		else if ( $do == "Edit") {
			if ( isset($_GET['id']) ) {

				$the_user_id = $_GET['id'];
				$sql = "SELECT * FROM users WHERE id = '$the_user_id' ";
				$the_user = mysqli_query($db, $sql);
				while ( $row = mysqli_fetch_assoc( $the_user )) {
					$edit_id 			= $row['id'];
					$name 				= $row['name'];
					$username 			= $row['username'];
					$email 				= $row['email'];
					$phone 				= $row['phone'];
					$address 			= $row['address'];
					$role 				= $row['role'];
					$existing_image 	= $row['image'];
					?>


					<!-- Main content start -->    
					<section class="content">
					    <div class="container-fluid">
					        <div class="row">
					          	<div class="col-md-12">
					          		<div class="card card-primary">
					          			<div class="card-header">
					          				<h3 class="card-title">Add New User</h3>
					          			</div>
					          			<div class="card-body">
					          				<form action="users.php?do=Update" method="POST" enctype="multipart/form-data">
					          					
					          					<div class="row">
					          						<div class="col-md-6">
					          							<fieldset disabled>
							          						<div class="form-group">
							          							<label for="disabledTextInput">Username</label>
							          							<input type="text" id="disabledTextInput" placeholder="username" name="username" required="required" class="form-control" value="<?php echo $username ;?>">
							          						</div>
							          					</fieldset>

						          						<div class="form-group">
						          							<label for="">Full Name</label>
						          							<input type="text" placeholder="Full Name" name="name" required="required" class="form-control" value="<?php echo $name ;?>">
						          						</div>

						          						<div class="form-group">
						          							<label for="">Email Addess</label>
						          							<input type="email" placeholder="" name="email" required="required" class="form-control" value="<?php echo $email ;?>">
						          						</div>

						          						<div class="form-group">
						          							<label for="">Phone No</label>
						          							<input type="text" placeholder="Phone no." name="phone" class="form-control" value="<?php echo $phone ;?>">
						          						</div>
						          						<div class="form-group">
						          							<label for="">Address</label>
						          							<input type="text" placeholder="Address" name="address" class="form-control" value="<?php echo $address ;?>">
						          						</div>
						          					</div>

						          					<div class="col-md-6">
						          						<div class="form-group">
						          							<label for="">Password</label>
						          							<input type="password" placeholder="Enter New Password" name="password" class="form-control">
						          						</div>

						          						<div class="form-group">
						          							<label for="">Retype password</label>
						          							<input type="password" placeholder="Retype New password" name="repassword" class="form-control">
						          						</div>

						          						<div class="form-group">
						          							<label for="">User Role</label>
						          							<select name="role" id="" class="form-control">
						          								<option value="0">Please select User Role</option>
						          								<option value="1" <?php if ( $role == 1) {echo "Selected";}?> >Super Admin</option>
						          								<option value="2" <?php if ( $role == 2) {echo "Selected";}?>>Editor</option>
						          								<option value="0" <?php if ( $role == 0) {echo "Selected";}?>>Inactive</option>
						          							</select>
						          						</div>

						          						<div class="form-group">
						          							<label for="">User Avater Image</label>

						          							<?php 

						          								if (!empty($existing_image)) {
						          									?>
						          									<img src="dist/img/users/<?php echo $existing_image; ?>" alt="" width="75" style="display: block; margin-bottom:10px;">

						          									<?php
						          								}
						          								else{
						          									?>

						          									<img src="dist/img/users/avatar.png" alt="" width="75"  style="display: block; margin-bottom:10px;"> 

						          									<?php
						          								}
						          							?>
						          							
						          							<input type="file" name="image" class="form-control-file">
						          						</div>

						          						<div class="form-group">
						          							<input type="hidden" name="update" value="<?php echo $edit_id; ?>">
						          							<input type="submit" name="save" value="Save Change" class="btn btn-primary btn-block">
						          						</div>

						          					</div>
					          					</div>

					          				</form>

					          			</div>
					          		</div>
					          	</div>
					      	</div>
					    </div>
					</section>
					<!-- Main content end -->


					<?php
				}
			}
		}
		else if ( $do == "Update") {
			if (isset($_POST['update'])) {

				$the_update_id 		= $_POST['update'];
				$name 				= $_POST['name'];
				$email 				= $_POST['email'];
				$phone 				= $_POST['phone'];
				$address 			= $_POST['address'];
				$password 			= $_POST['password'];
				$repassword 		= $_POST['repassword'];
				$role 				= $_POST['role'];
				$image 				= $_FILES['image']['name'];
				$image_temp 		= $_FILES['image']['tmp_name'];


				if ( !empty($password) ) {
					
					if ( $password == $repassword ) {
						
						$hassedPass = sha1($password);
						$sql ="UPDATE users SET password = '$hassedPass' WHERE id = '$the_update_id' ";
						$update_password = mysqli_query($db, $sql);
					}

					if (!empty($image)) {

						// delete the user existing image form user the folder
						$sql ="SELECT * FROM users WHERE id = '$the_update_id' ";

						$del_user = mysqli_query($db, $sql);

						while ( $row = mysqli_fetch_assoc($del_user) ) {
							$user_image = $row['image'];
						}
						unlink("dist/img/users/$user_image");

						// Image file name change and move to the folder
						$random_number = rand(0, 1000000);
						$imageFile = $random_number.$image;

						move_uploaded_file($image_temp, "dist/img/users/".$imageFile );



						$sql = "UPDATE users SET name = '$name', email='$email', phone='$phone', address='$address', role='$role', image='$imageFile' WHERE id='$the_update_id' ";
						$update_info = mysqli_query($db, $sql);

						if ( $update_info ) 
						{
							header("Location: users.php?do=Manage");
						}
						else{
							die("Query Filed" . mysqli_error($db) );
						}
					}
					
					else{

						$sql = "UPDATE users SET name = '$name', email='$email', phone='$phone', address='$address', role='$role' WHERE id='$the_update_id' ";

						$update_info = mysqli_query($db, $sql);

						if ( $update_info ) 
						{
							header("Location: users.php?do=Manage");
						}
						else{
							die("Query Filed" . mysqli_error($db) );
						}

					}



				}
			}
		}
		else if ( $do == "Delete") {
			
			if (isset($_GET['deleteUser'])) {

				$del_id = $_GET['deleteUser'];



				// delete the user existing image form user the folder
				$sql ="SELECT * FROM users WHERE id = '$del_id' ";

				$del_user = mysqli_query($db, $sql);

				while ( $row = mysqli_fetch_assoc($del_user) ) {
					$user_image = $row['image'];
				}
				unlink("dist/img/users/$user_image");


				// delete the form database
				$del_sql = "DELETE FROM users WHERE id = '$del_id' ";

				$delete_the_user = mysqli_query($db, $del_sql);

				if ( $delete_the_user ) 
				{
					header("Location: users.php?do=Manage");
				}
				else{
					die("Query Filed" . mysqli_error($db) );
				}
			}
		}

    
        
?>

	


	<!-- Main content start -->    
	<!-- <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	          	<div class="col-md-12">
					<div class="card card-primary">
	          			<div class="card-header">
	          				<h3 class="card-title">All Users</h3>
	          			</div>
	          			<div class="card-body">

	          			</div>

			        </div>
	          	</div>
	      	</div>
	    </div>
	</section> -->
	<!-- Main content end -->

</div>



<?php include "includes/footer.php"; ?>