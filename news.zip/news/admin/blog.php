<?php include "includes/header.php"; ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<div class="content-header">
	  <div class="container-fluid">
	    <div class="row mb-2">
	      <div class="col-sm-6">
	        <h1 class="m-0">Dashboard </h1>
	      </div><!-- /.col -->
	      <div class="col-sm-6">
	        <ol class="breadcrumb float-sm-right">
	          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
	          <li class="breadcrumb-item active">Blog </li>
	        </ol>
	      </div><!-- /.col -->
	    </div><!-- /.row -->
	  </div><!-- /.container-fluid -->
	</div>
	<!-- /.content-header -->


	<?php 

			
	$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

	if ( $do == "Manage") {
		# code...
		?>

		<!-- Main content start -->    
		<section class="content">
		    <div class="container-fluid">
		        <div class="row">
		          	<div class="col-md-12">
		          		<!-- User Management card start  -->
		          		<div class="card card-primary">
		          			<div class="card-header">
		          				<h3 class="card-title">All Users</h3>
		          			</div>
		          			<div class="card-body">

		          				<table class="table table-striped table-bordered">
									<thead class="table-dark">
									    <tr>
										    <th scope="col">Sl.</th>
										    <th scope="col">Ttile</th>
										    <th scope="col">Thumbnail</th>
										    <th scope="col">Category</th>
										    <th scope="col">Published By</th>
										    <th scope="col">Date</th>
										    <th scope="col">Action</th>
									    </tr>
									</thead>
									<tbody>

									<?php

									$sql="SELECT * FROM post";
									$all_post = mysqli_query($db, $sql);
									$i = 0;
									while ( $row = mysqli_fetch_assoc($all_post) ) {
											
										$post_id 		= $row['post_id'];
										$title 			= $row['title'];
										$description 	= $row['description'];
										$thumbnail 		= $row['thumbnail'];
										$category_id 	= $row['category_id'];
										$author_id 		= $row['author_id'];
										$postDate 		= $row['postDate'];
										$i++

										?>

										<tr>
										    <th scope="row"><?php echo $i ;?></th>
										    <td><?php echo $title ;?></td>
										    <td>
										    	<?php
										    		if (empty($thumbnail)) {
										    			?>
										    				<img src="dist/img/posts/default.png" alt="" class="avater-img">
										    			<?php
										    		}
										    		else{
										    			?>
										    				<img src="dist/img/posts/<?php echo $thumbnail ;?>" alt="" class="avater-img">
										    			<?php
										    		}
										    	?>	
										    	
										    </td>
										    
										    <td>
										    	<?php 
													$sql = "SELECT * FROM categories WHERE cat_id = '$category_id' ";

								          			$the_cat_name = mysqli_query($db, $sql);

								          			while ( $row = mysqli_fetch_assoc($the_cat_name)) {
								          				$cat_id 		= $row['cat_id'];
														$cat_name 		= $row['cat_name'];

													}
													echo $cat_name;
										    	?>
										    </td>
										    <td>
										    	
										    	<?php 
													$sql = "SELECT * FROM users WHERE id = '$author_id' ";

								          			$the_author_name = mysqli_query($db, $sql);

								          			while ( $row = mysqli_fetch_assoc($the_author_name)) {
								          				$id 		= $row['id'];
														$name 		= $row['name'];

													}
													echo $name;
										    	?>

										    </td>
										    <td><?php echo $postDate ;?></td>
										    
										    <td>
										    	
										    	<div class="action-menu">
										    		<ul>
									      				<li>
									      					<a href="blog.php?do=Edit&id=<?php echo $post_id; ?>">
									      						<i class="fa fa-edit" data-toggle="tooltip" data-placement="bottom" title="Update Post"></i>
									      					</a>
									      				</li>
									      				<li data-toggle="modal" data-target="#delete<?php echo $post_id; ?>">
									     
									      					<i class="fa fa-trash" data-toggle="tooltip" data-placement="bottom" title="Delete Post"></i>
									      					
									      				</li>

									      			</ul>


									      			<!-- Modal -->
													<div class="modal fade" id="delete<?php echo $post_id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
													  <div class="modal-dialog">
													    <div class="modal-content">
													      <div class="modal-header">
													        <h5 class="modal-title" id="exampleModalLabel">Are you sure to Delete this Post?</h5>
													        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
													          <span aria-hidden="true">&times;</span>
													        </button>
													      </div>
													      <div class="modal-body">
													      	<div class="modal-button">
												      		<a href="blog.php?do=Delete&the_del_id=<?php echo $post_id; ?>" class="btn btn-danger">Yes</a>
												        	<button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
												      	</div>
													      </div>
													      
													    </div>
													  </div>
													</div>
										    	</div>
										    </td>
									    </tr>

										<?php } ?>   
									   
									</tbody>
								</table>

		          			</div>
		          		</div>
		          		<!-- User Management card End  -->

		          	</div>

		          	<div class="col-md-12">
		          		<a href="blog.php?do=Add" class="btn btn-primary">Add New Post</a>
		          	</div>
		      	</div>
		    </div>
		</section>
		<!-- Main content end -->
		
	<?php }
	else if( $do == "Add"){ ?>

		<!-- Main content start -->    
		<section class="content">
		    <div class="container-fluid">
		        <div class="row">
		          	<div class="col-md-12">
		          		<div class="card card-primary">
		          			<div class="card-header">
		          				<h3 class="card-title">Add New Post</h3>
		          			</div>
		          			<div class="card-body">
		          				<form action="blog.php?do=Insert" method="POST" enctype="multipart/form-data">
		          					
		          					<div class="row">
		          						<div class="col-md-6">
			          						<div class="form-group">
			          							<label for="">Title</label>
			          							<input type="text" name="title" required="required" class="form-control">
			          						</div>

			          						<div class="form-group">
			          							<label for="">Category Name</label>
			          							<select name="category_id" class="form-control">
			          								
			          								<option value="0">Please select a category</option>

			          								<?php
			          									$sql = "SELECT * FROM categories WHERE cat_status = 1";
			          									$all_cat = mysqli_query($db, $sql);;

			          									while ($row = mysqli_fetch_assoc($all_cat)) {
			          										
			          										$cat_id 	= $row['cat_id'];
			          										$cat_name 	= $row['cat_name'];

			          										?>

			          										<option value="<?php echo $cat_id; ?>">
			          											<?php echo $cat_name; ?>
			          										</option>
			          										<?php
			          									}
			          								?>


			          							</select>
			          						</div>

			          						<div class="form-group">
			          							<label for="">Post Thumbnail</label>
			          							<input type="file" name="thumbnail" class="form-control-file">
			          						</div>

			          						
			          					</div>

			          					<div class="col-md-6">
			          						<div class="form-group">
			          							<label for="">Description</label>
			          							<textarea name="description" class="form-control" cols="20" rows="6"></textarea>

			          						</div>

			          						<div class="form-group">
			          							
			          							<input type="submit" name="publish" value="Publish Post" class="btn btn-primary btn-block">
			          						</div>

			          					</div>
		          					</div>

		          				</form>

		          			</div>
		          		</div>
		          	</div>
		      	</div>
		    </div>
		</section>
		<!-- Main content end -->
		
	<?php }
	else if ( $do == "Insert") {
		
		if (isset($_POST['publish'])) {
			# code...
			$title 			= mysqli_real_escape_string($db, $_POST['title']);
			$description 	= mysqli_real_escape_string($db, $_POST['description']);
			$category_id 	= $_POST['category_id'];
			$author_id 		= $_SESSION['id']; 

			$thumbnail 		= $_FILES['thumbnail']['name'];
			$image_temp 	= $_FILES['thumbnail']['tmp_name'];

		
			// Image file name change and move to the folder
			$random_number = rand(0, 1000000);
			$imageFile = $random_number.$thumbnail;
			move_uploaded_file($image_temp, "dist/img/posts/".$imageFile );

			$sql = "INSERT INTO post (title, description, thumbnail, category_id, author_id, postDate) VALUES ('$title', '$description', '$imageFile', '$category_id', '$author_id', now() ) ";

			$addPost = mysqli_query($db, $sql);

			if ( $addPost ) 
			{
				header("Location: blog.php?do=Manage");
			}
			else{
				die("Query Filed" . mysqli_error($db) );
			}
			
		}
		else{

		}
	}
	else if ( $do == "Edit") {
		if ( isset($_GET['id']) ) {

			$the_post_id = $_GET['id'];
			$sql = "SELECT * FROM post WHERE post_id = '$the_post_id' ";
			$the_post = mysqli_query($db, $sql);
			while ( $row = mysqli_fetch_assoc( $the_post )) {

				$blog_post_id 	= $row['post_id'];
				$title 			= $row['title'];
				$description 	= $row['description'];
				$category_id 	= $row['category_id'];
				$author_id 		= $row['author_id'];
				$postDate 		= $row['postDate'];
				$thumbnail 		= $row['thumbnail'];


				?>


				<!-- Main content start -->    
				<section class="content">
				    <div class="container-fluid">
				        <div class="row">
				          	<div class="col-md-12">
				          		<div class="card card-primary">
				          			<div class="card-header">
				          				<h3 class="card-title">Update Post Information</h3>
				          			</div>
				          			<div class="card-body">
				          				<form action="blog.php?do=Update" method="POST" enctype="multipart/form-data">
		          					
				          					<div class="row">
				          						<div class="col-md-6">
					          						<div class="form-group">
					          							<label for="">Title</label>
					          							<input type="text" name="title" class="form-control" value="<?php echo $title; ?>">
					          						</div>

					          						<div class="form-group">
					          							<label for="">Category Name</label>
					          							<select name="category_id" class="form-control">
					          								
					          								<option value="0">Please select a category</option>

					          								<?php
					          									$sql = "SELECT * FROM categories WHERE cat_status = 1";
					          									$all_cat = mysqli_query($db, $sql);;

					          									while ($row = mysqli_fetch_assoc($all_cat)) {
					          										
					          										$cat_id 	= $row['cat_id'];
					          										$cat_name 	= $row['cat_name'];

					          										?>

					          										<option value="<?php echo $cat_id; ?>" <?php if ( $cat_id == $category_id) { echo 'selected';}?>>
					          											<?php echo $cat_name; ?>
					          										</option>
					          										<?php
					          									}
					          								?>


					          							</select>
					          						</div>

					          						<div class="form-group">
					          							<label for="">Post Thumbnail</label>
					          							<br/>
					          							<?php 

					          								if (!empty($thumbnail)) {
					          									?>
					          									<img src="dist/img/posts/<?php echo $thumbnail; ?>" alt="" style="display:block;width:180px;">
					          									<?php
					          								}else{
					          									?>
					          									<img src="dist/img/posts/default.png" alt="" style="display:block;width:180px;">

					          									<?php
					          								}
					          							?>
					          							<br/>
					          							<input type="file" name="thumbnail" class="form-control-file">
					          						</div>

					          						
					          					</div>

					          					<div class="col-md-6">
					          						<div class="form-group">
					          							<label for="">Description</label>
					          							<textarea name="description" class="form-control" rows="6"><?php echo $description; ?></textarea>

					          						</div>

					          						<div class="form-group">
					          							<input type="hidden" name="update" value="<?php echo $blog_post_id; ?>">
					          							<input type="submit" name="publish" value="Save Change" class="btn btn-primary btn-block">
					          						</div>

					          					</div>
				          					</div>

				          				</form>
				          			</div>
				          		</div>
				          	</div>
				      	</div>
				    </div>
				</section>
				<!-- Main content end -->


				<?php
			}
		}
	}
	else if ( $do == "Update") {
		
		if (isset($_POST['update'])) {

			$the_update_id 	= $_POST['update'];
			$title 			= mysqli_real_escape_string($db, $_POST['title']);
			$description 	= mysqli_real_escape_string($db, $_POST['description']);
			$category_id 	= $_POST['category_id'];
			$author_id 		= $_SESSION['id'];

			$thumbnail 		= $_FILES['thumbnail']['name'];
			$image_temp 	= $_FILES['thumbnail']['tmp_name'];


			if (!empty($thumbnail)) {

				// Image file name change and move to the folder
				$random_number = rand(0, 1000000);
				$imageFile = $random_number.$thumbnail;

				move_uploaded_file($image_temp, "dist/img/posts/".$imageFile );



				$sql = "UPDATE post SET title = '$title', description='$description', thumbnail='$imageFile', category_id='$category_id' WHERE post_id='$the_update_id' ";

				$updatepost = mysqli_query($db, $sql);

				if ( $updatepost ) 
				{
					header("Location: blog.php?do=Manage");
				}
				else{
					die("Query Filed" . mysqli_error($db) );
				}
			}
				
			else{

				$sql = "UPDATE post SET title = '$title', description='$description', category_id='$category_id' WHERE post_id='$the_update_id' ";

				$updatepost = mysqli_query($db, $sql);

				if ( $updatepost ) 
				{
					header("Location: blog.php?do=Manage");
				}
				else{
					die("Query Filed" . mysqli_error($db) );
				}
			}

		}


	}
	else if ( $do == "Delete") {
		if (isset($_GET['the_del_id'])) {
			
			$del_id = $_GET['the_del_id'];

			//delete images form database and folder and move image
			$sql ="SELECT * FROM post WHERE post_id = '$del_id' ";
			$del_post_thumbnail = mysqli_query($db, $sql);

			while ( $row = mysqli_fetch_assoc($del_post_thumbnail)) {
				
				$thumbnail = $row['image'];
			}

			unlink("dist/img/posts/$thumbnail");


			// delete user form database

			$del_sql ="DELETE FROM post WHERE post_id = '$del_id' "; 

			$delete_the_post = mysqli_query($db, $del_sql);

			if ( $delete_the_post ) {
				header("Location: blog.php?do=Manage");
			}
			else{
				die("Query Field" . mysqli_error($db));
			}
		}
	}


		

	?>



	<!-- Main content start -->    
	<!-- <section class="content">
	    <div class="container-fluid">
	        <div class="row">
	          	<div class="col-md-12">
	          		<div class="card card-primary">
	          			<div class="card-header">
	          				<h3 class="card-title">Add New Category</h3>
	          			</div>
	          			<div class="card-body">




	          			</div>
	          		</div>
	          	</div>
	      	</div>
	    </div>
	</section> -->
	<!-- Main content end -->






</div>



<?php include "includes/footer.php"; ?>